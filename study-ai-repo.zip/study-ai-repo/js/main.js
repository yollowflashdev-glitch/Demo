  // ---------- mobile nav ----------
  const navToggle = document.getElementById('navToggle');
  const navMobile = document.getElementById('navMobile');
  navToggle.addEventListener('click', () => {
    const open = navMobile.classList.toggle('is-open');
    navToggle.setAttribute('aria-expanded', open ? 'true' : 'false');
  });
  navMobile.querySelectorAll('a').forEach(a => a.addEventListener('click', () => {
    navMobile.classList.remove('is-open');
    navToggle.setAttribute('aria-expanded', 'false');
  }));

  const reduceMotion = window.matchMedia('(prefers-reduced-motion: reduce)').matches;

  // ---------- starfield background ----------
  (function starfield(){
    const canvas = document.getElementById('starfield');
    const ctx = canvas.getContext('2d');
    let stars = [];

    function resize(){
      canvas.width = window.innerWidth;
      canvas.height = document.body.scrollHeight;
      const count = Math.floor((canvas.width * canvas.height) / 9000);
      stars = Array.from({length: count}, () => ({
        x: Math.random() * canvas.width,
        y: Math.random() * canvas.height,
        r: Math.random() * 1.1 + 0.2,
        a: Math.random() * 0.6 + 0.1,
        tw: Math.random() * 0.015 + 0.003,
        dir: Math.random() > 0.5 ? 1 : -1
      }));
    }

    function draw(){
      ctx.clearRect(0,0,canvas.width,canvas.height);
      ctx.fillStyle = '#e9edf6';
      stars.forEach(s => {
        if(!reduceMotion){
          s.a += s.tw * s.dir;
          if(s.a > 0.7 || s.a < 0.1) s.dir *= -1;
        }
        ctx.globalAlpha = s.a;
        ctx.beginPath();
        ctx.arc(s.x, s.y, s.r, 0, Math.PI*2);
        ctx.fill();
      });
      ctx.globalAlpha = 1;
      if(!reduceMotion) requestAnimationFrame(draw);
    }

    window.addEventListener('resize', resize);
    resize();
    draw();
  })();

  // ---------- hero constellation ----------
  (function constellation(){
    const canvas = document.getElementById('constellation');
    const ctx = canvas.getContext('2d');
    const container = canvas.parentElement;
    let w, h, nodes;
    const labels = ['Math','History','Chem','Code','Spanish','Biology','Music','Physics'];
    const colors = ['#5eead4','#9b8cff','#ffb454'];

    function size(){
      w = canvas.width = container.clientWidth;
      h = canvas.height = container.clientHeight;
      const cx = w/2, cy = h/2;
      nodes = [{x:cx,y:cy,vx:0,vy:0,r:7,label:'YOU',center:true,color:'#e9edf6'}];
      labels.forEach((label,i) => {
        const angle = (i / labels.length) * Math.PI*2 + 0.3;
        const dist = Math.min(w,h) * (0.30 + (i%3)*0.05);
        nodes.push({
          x: cx + Math.cos(angle)*dist,
          y: cy + Math.sin(angle)*dist,
          vx:(Math.random()-0.5)*0.15,
          vy:(Math.random()-0.5)*0.15,
          r:3.4,
          label,
          color: colors[i % colors.length]
        });
      });
    }

    function step(){
      ctx.clearRect(0,0,w,h);

      // connections from center
      nodes.forEach((n,i) => {
        if(i===0) return;
        const center = nodes[0];
        ctx.beginPath();
        ctx.moveTo(center.x, center.y);
        ctx.lineTo(n.x, n.y);
        ctx.strokeStyle = 'rgba(124,137,168,0.28)';
        ctx.lineWidth = 1;
        ctx.stroke();
      });

      // faint cross-links
      for(let i=1;i<nodes.length;i++){
        const a = nodes[i], b = nodes[(i % (nodes.length-1)) + 1];
        ctx.beginPath();
        ctx.moveTo(a.x,a.y);
        ctx.lineTo(b.x,b.y);
        ctx.strokeStyle = 'rgba(124,137,168,0.10)';
        ctx.stroke();
      }

      nodes.forEach((n,i) => {
        if(!reduceMotion && i>0){
          n.x += n.vx; n.y += n.vy;
          if(n.x < w*0.08 || n.x > w*0.92) n.vx *= -1;
          if(n.y < h*0.08 || n.y > h*0.92) n.vy *= -1;
        }
        ctx.beginPath();
        ctx.arc(n.x, n.y, n.r, 0, Math.PI*2);
        ctx.fillStyle = n.color;
        ctx.shadowColor = n.color;
        ctx.shadowBlur = n.center ? 16 : 10;
        ctx.fill();
        ctx.shadowBlur = 0;

        ctx.font = n.center ? '600 13px IBM Plex Mono, monospace' : '11px IBM Plex Mono, monospace';
        ctx.fillStyle = n.center ? '#e9edf6' : 'rgba(233,237,246,0.75)';
        ctx.textAlign = 'center';
        ctx.fillText(n.label, n.x, n.y - n.r - 8);
      });

      if(!reduceMotion) requestAnimationFrame(step);
    }

    window.addEventListener('resize', size);
    size();
    step();
  })();

  // ---------- count-up stats ----------
  (function countUp(){
    const els = document.querySelectorAll('.stat-num');
    const observer = new IntersectionObserver((entries) => {
      entries.forEach(entry => {
        if(!entry.isIntersecting) return;
        const el = entry.target;
        const target = parseFloat(el.dataset.target);
        const decimals = parseInt(el.dataset.decimals || '0', 10);
        if(reduceMotion){
          el.textContent = target.toFixed(decimals);
          observer.unobserve(el);
          return;
        }
        const duration = 1100;
        const start = performance.now();
        function frame(now){
          const t = Math.min(1, (now - start) / duration);
          const eased = 1 - Math.pow(1 - t, 3);
          el.textContent = (target * eased).toFixed(decimals);
          if(t < 1) requestAnimationFrame(frame);
        }
        requestAnimationFrame(frame);
        observer.unobserve(el);
      });
    }, {threshold: 0.4});
    els.forEach(el => observer.observe(el));
  })();