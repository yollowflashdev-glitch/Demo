# Study AI — Landing Page

A dark, futuristic landing page concept for **Study AI**, an all-in-one study platform (AI tutor, flashcards, notes, practice tests, and progress tracking) built for learners of all ages.

## Live preview
Open `index.html` directly in a browser, or serve it locally:

```bash
npx serve .
```

Then visit `http://localhost:3000`.

## Project structure
```
study-ai/
├── index.html        # Page markup
├── css/
│   └── style.css     # All styling (design tokens, layout, responsive rules)
├── js/
│   └── main.js        # Starfield + constellation animation, count-up stats, mobile nav
├── assets/            # Place favicon, og-image, and any future images here
└── README.md
```

## Design notes
- **Palette:** near-black void background (`#080b14`) with cyan, violet, and amber accents
- **Type:** Space Grotesk (display) + Inter (body) + IBM Plex Mono (data/labels)
- **Signature element:** a connected "constellation" motif — a central node radiating to subject nodes — used in the hero animation and echoed in the features grid, representing the all-in-one nature of the product
- Respects `prefers-reduced-motion` and keeps visible keyboard focus states

## Deploying with GitHub Pages
1. Push this repo to GitHub
2. Go to **Settings → Pages**
3. Set source to the `main` branch, root folder
4. Your site will be live at `https://<username>.github.io/<repo-name>/`

## License
MIT — see `LICENSE`.
